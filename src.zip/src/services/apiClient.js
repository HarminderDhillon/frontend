// src/services/apiClient.js
const BASE_URL = import.meta.env.VITE_API_BASE_URL || "http://localhost:3000/api/auth"; // Vite proxy will help locally

const getToken = () => localStorage.getItem("token");

export async function customFetch(path, options = {}) {
  const headers = {
    "Content-Type": "application/json",
    ...(getToken() && { Authorization: `Bearer ${getToken()}` }),
    ...options.headers,
  };

  const response = await fetch(`${BASE_URL}${path}`, {
    ...options,
    headers,
  });

  let data;
  try {
    data = await response.json();
  } catch (e) {
    throw new Error("Invalid JSON response from server");
  }

  if (!response.ok) {
    const error = data.error || "Something went wrong";
    throw new Error(error);
  }

  return data;
}

export function logout() {
  localStorage.removeItem("token");
}





















// class ApiClient {
//   constructor() {
//     this.baseURL = import.meta.env.VITE_API_URL || "http://localhost:8082/api/auth";
//     this.defaultHeaders = {
//       "Content-Type": "application/json",
//       Accept: "application/json",
//     };
//   }

//   async customFetch(endpoint, options = {}) {
//     const url = `${this.baseURL}${endpoint}`;
//     const token = localStorage.getItem("token");
//     const headers = {
//       ...this.defaultHeaders,
//       ...options.headers,
//     };

//     if (token) {
//       headers["Authorization"] = `Bearer ${token}`;
//     }

//     const config = {
//       ...options,
//       headers,
//       credentials: "include",
//     };

//     try {
//       console.log(`🔗 Fetching ${url}`);
//       const response = await fetch(url, config);

//       if (!response.ok) {
//         const errorData = await response.json();
//         throw { status: response.status, message: errorData.message || "Unknown Error" };
//       }

//       return await response.json();
//     } catch (error) {
//       console.error("❌ API Error:", error);
//       throw error;
//     }
//   }

//   async signup(name, email, password) {
//     return this.customFetch("/register", {
//       method: "POST",
//       body: JSON.stringify({ username: name, email, password }),
//     });
//   }

//   async login(email, password) {
//     return this.customFetch("/login", {
//       method: "POST",
//       body: JSON.stringify({ email, password }),
//     });
//   }
// }

// const apiClient = new ApiClient();
// export default apiClient;
